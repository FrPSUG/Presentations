<# </> Get function URL
    https://parispowershellsaturday.azurewebsites.net/api/Demo3?code=4HOM6J9YXmVC5KlJMMNA145BcrHDh40pWtaU1suw6HLbZufOmorTWg==
#>

# Add Tls 1.2 to security, otherwise command errors out
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$FirstFunctionSplat = @{
    Uri = 'https://parispowershellsaturday.azurewebsites.net/api/Demo3?code=4HOM6J9YXmVC5KlJMMNA145BcrHDh40pWtaU1suw6HLbZufOmorTWg=='
    Method = 'post'
    ContentType = 'application/json'
    Body = [pscustomobject]@{Name='Variable'} | ConvertTo-Json
}
Invoke-RestMethod @FirstFunctionSplat

# Add Tls 1.2 to security, otherwise command errors out

Invoke-RestMethod @FirstFunctionSplat

$FirstFunctionSplat.Body = [pscustomobject]@{Name='ResReq'} | ConvertTo-Json
Invoke-RestMethod @FirstFunctionSplat

# Show function.json configuration
# Show Function App variable configuration

$FirstFunctionSplat.Body = [pscustomobject]@{Name='Modules'} | ConvertTo-Json
Invoke-RestMethod @FirstFunctionSplat

$FirstFunctionSplat.Body = [pscustomobject]@{Name='AzureVersion'} | ConvertTo-Json
Invoke-RestMethod @FirstFunctionSplat