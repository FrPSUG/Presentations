﻿
##########################################################################################
# Contexte : 
# 1 siége commun pour 2 société. 1 domaine AD dans lequelle nous avons 3 OU :
# Entité1 : une entreprise en entité1.org pour la messagerie
# Entité2 : une entreprise en entité2.fr pour la messagerie
# Entité3 : une groupement d'intérêt public pour la gestion des 2 SI en entité3.fr pour la messagerie
#
#
#
# BUT : 
# Le support N0 (prise d'appel)est externalisé. Le N1 (technique) est fait en interne.
# Le but était de fournir un script réunissant toutes les petites fonctions que j'ai faite 
# pour me faciliter la vie afin de faire gagner du temps au N0 et N1, que tous soit fait toujours de la même façon 
# 
# Le script propose de faire  : 
#  -  la gestion de compte AD (creation / suppression), 
#  -  la gestion Office 365 (migration de boite mail/ activation archvie en ligne...), 
#  - et une fonction pour la gestion des RDS (recherche du serveur su lequel se trouve un user)#


# Notes: 
# Ce script est utilisé sous Ad en 2012 R2 (PS v4) par des personnes du N0/N1.
# La plupart des serveurs minimum 2012, quelques 2008 et 2003 à droite et gauche
# 
# Pb: le compte admin est utilisé pour exécuter ce script
# Il ne s'agit pas de traitements automatisée.


#LD propositions :
# Menu basé sur System.Management.Automation.Host.ChoiceDescription
# verbe Ask -> Read
# La gestion des menu pourrait être un paramètrage ou via ce module : https://ps2wiz.codeplex.com/documentation
# Supprimer les globales
# Revoir l'usage du Snapin Quest.
# Ajouter une gestion d'erreur

#Le contrôle de certaines règles doit être renforcée : cf. "Prénom de l'utilisateur (sans accent, sans point) 

# Améliorer les requêtes AD : $streetaddress = get-QADUser -Identity $global:comptesource  -properties StreetAddress

# Si c'est un numéro de choix de menu utiliser un type entier
#$global:domaine = "0"
#$global:askuser = 1

#Add-Type Préférable ici, ce n'est pas un module binaire Powershell mais un assembly dotnet
#Import-Module "AlphaFS.dll"
#etc ...


#region <Initialization>
Clear-Host
$Host.UI.RawUI.WindowTitle = "IT Support"
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force
$global:domaine = "0"
$global:askuser = 1
#endregion

#region <Import Module>
Add-PSSnapin Quest.ActiveRoles.ADManagement
Import-module ActiveDirectory
Import-Module NTFSSecurity
Import-Module "C:\Windows\System32\WindowsPowerShell\v1.0\Modules\AlphaFS\AlphaFS.dll"
Import-Module MsOnline
Import-Module PSTerminalServices
#endregion

#region <Menu>
function Show-PrincipalMenu
 {
      param (
            [string]$Title = 'IT Support'
      )
      Clear-Host
      Write-Host "================ $Title ================" -ForegroundColor Cyan
      
      Write-Host "1: AD User management." -ForegroundColor Green
      Write-Host "2: Office 365 mamagement." -ForegroundColor Green
      Write-Host "3: RDS management." -ForegroundColor Green
      Write-Host "Q: to quit." -ForegroundColor Red

      do
{
      $input = Read-Host "Please make a selection"
      switch ($input)
      {
            '1' {
                 Clear-Host
                 Show-UserMenu
            } '2' {
                 Clear-Host
                 Show-Office365Menu
            } '3' {
                 Clear-Host
                 Show-RDSMenu
            } 'q' {
                CloseSession
				exit
            }
      }
 }
 until ($input -eq 'q')
 }

function Show-UserMenu
 {
      param (
            [string]$Title = 'AD User Management'
      )
      Clear-Host
      Write-Host "================ $Title ================" -ForegroundColor Cyan
      
      Write-Host "1: create AD User." -ForegroundColor Green
      Write-Host "2: remove AD User." -ForegroundColor Green
      Write-Host "3: this option." -ForegroundColor Green
      Write-Host "P: previous menu." -ForegroundColor Green
      Write-Host "Q: to quit." -ForegroundColor Red
      do
{
      $input = Read-Host "Please make a selection"
      switch ($input)
      {
            '1' {
                 Clear-Host
                 'You chose option #1'
                 CreateAdUser
                 $global:askuser = 1
                 Show-UserMenu
            } '2' {
                 Clear-Host
                 RemoveAdUser
                 $global:askuser = 1
                 Show-UserMenu
            } '3' {
                 Clear-Host
				 $global:askuser = 1
                 Show-UserMenu
            } 'p' {
                 Show-PrincipalMenu
            } 'q' {
               CloseSession
			   exit 
            }
      }
 }
 until ($input -eq 'q')
 }

 function Show-Office365Menu
 {
      param (
            [string]$Title = 'Office 365 Management'
      )
      Clear-Host
      Write-Host "================ $Title ================" -ForegroundColor Cyan
      
      Write-Host "1: Set Online Archive." -ForegroundColor Green
      Write-Host "2: Set Online Mailbox." -ForegroundColor Green
      Write-Host "3: Create Shared Mailbox." -ForegroundColor Green
      Write-Host "P: previous menu." -ForegroundColor Green
      Write-Host "Q: to quit." -ForegroundColor Red
      do
{
      $input = Read-Host "Please make a selection"
      switch ($input)
      {
            '1' {
                 Clear-Host
                 Set-OnlineArchive
                 $global:askuser = 1
                 Show-Office365Menu
            } '2' {
                 Clear-Host
                 Set-OnlineMailbox
                 $global:askuser = 1
                 Show-Office365Menu
            } '3' {
                 Clear-Host
                 Create-SharedMailbox
				 $global:askuser = 1
                 Show-Office365Menu
            } 'p' {
                 Show-PrincipalMenu
            } 'q' {
               CloseSession
			   exit 
            }
      }
 }
 until ($input -eq 'q')
 }
 
 function Show-RDSMenu
 {
      param (
            [string]$Title = 'RDS Management'
      )
      Clear-Host
      Write-Host "================ $Title ================" -ForegroundColor Cyan
      
      Write-Host "1: Find RDS User." -ForegroundColor Green
      Write-Host "2: This option." -ForegroundColor Green
      Write-Host "3: This option." -ForegroundColor Green
      Write-Host "P: previous menu." -ForegroundColor Green
      Write-Host "Q: to quit." -ForegroundColor Red
      do
{
      $input = Read-Host "Please make a selection"
      switch ($input)
      {
            '1' {
                 Clear-Host
                 FindUserRDS
                 $global:askuser = 1
                 Show-RDSMenu
            } '2' {
                 Clear-Host
                 $global:askuser = 1
                Show-RDSMenu
            } '3' {
                 Clear-Host
				 $global:askuser = 1
                 Show-RDSMenu
            } 'p' {
                 Show-PrincipalMenu
            } 'q' {
               CloseSession
			   exit 
            }
      }
 }
 until ($input -eq 'q')
 }
#endregion

#region <Fonction>
function CloseSession
{
Remove-PSSnapin Quest.ActiveRoles.ADManagement
Remove-module ActiveDirectory
Remove-Module NTFSSecurity
Remove-Module PSTerminalServices
Remove-Module MsOnline
Close-Session
}

function SynchroDirsync
{
    param (
        $TTW = 30
    )
	Clear-Host
    Invoke-Command -ComputerName SRV-DIRSYNC01 -ScriptBlock { Import-Module DirSync; Start-OnlineCoexistenceSync }
    for ($a=$TTW; $a -ne 0; $a--) 
    { 
        Write-Progress -Activity "Synchronisation DirSync..." -SecondsRemaining $a -Status "Please wait." 
        Start-Sleep 1 
    }
}

function Ask-Domaine
{
do
{
  clear
  $global:domaine=Read-Host "Nom du domaine (entité1(1), entité2(2), entité3(3)) ? " 
  #$global:domaine=Read-Host "Nom du domaine (entité1(1), entité2(2) ? " 
}
until (($global:domaine -eq "1") -or ($global:domaine -eq "2") -or ($global:domaine -eq "3"))
#until (($global:domaine -eq "1") -or ($global:domaine -eq "2"))

}

function Ask-User
{
    Ask-Domaine
    
    do
    {
        clear
        [string]$global:prenom= Read-Host "Prénom de l'utilisateur (sans accent, sans point)  ? " 
    }
    until (([string]$Global:prenom.contains(“.”)) -eq $false)
    
    do
    {
        clear
        [string][string]$global:nom= Read-Host "Nom de l'utilisateur (sans accent, sans point)  ? "
    }
    until (([string]$Global:nom.contains(“.”)) -eq $false)
    

    Switch ($global:domaine)
{
	1 
        {	
        $global:OU = "OUuserentité1"
		$global:domaine = "entité1" 	
		$global:DATABASE = "ExchDatabaseentité1"
        $global:nom = $nom.ToUpper()
        $global:prenom = UpperFirstCar($Prenom)
        $global:username = ([string]$prenom[0]).ToUpper() +'.'+$nom.ToUpper()
        $global:password = "Password"
        $global:path= "Homedriveentité1"
        $global:ntaccount = "NETINTRA\"+$nom +' '+$prenom
		$global:OUBAL = "OuBalentité1"
		$global:OUGROUPE = "OuGroupeMessagerieentité1"
        }
	2 
        {
        $global:OU = "OUuserentité2"
		$global:domaine = "entité2" 
	    $global:DATABASE = "ExchDatabaseentité2"
        $global:nom = UpperFirstCar($nom)
        $global:prenom = UpperFirstCar($Prenom)
        $global:username = $prenom +'.'+$nom
        $global:password = "Password"
        $global:path = "Homedriveentité2"
        $global:ntaccount = "NETINTRA\"+$username
		$global:OUBAL = "OuBalentité2"
		$global:OUGROUPE = "OuGroupeMessagerieentité2"
        }
	3 
        {
        $global:OU = "OUuserentité3"
		$global:domaine = "entité3"
		$global:DATABASE = "ExchDatabaseentité3"
        $global:nom = UpperFirstCar($nom)
        $global:prenom = UpperFirstCar($Prenom)
        $global:username = $prenom +'.'+$nom
        $global:password = "Password"
        $global:ntaccount = "NETINTRA\"+$username
		$global:OUBAL = "OuBalentité3"
		$global:OUGROUPE = "OuGroupeMessagerieentité3"
        }
}
$global:displayname = $nom +' '+$prenom
$global:askuser = 0
}

function Ask-MigrationO365
{
do
{
  clear
  $global:migration=Read-Host "Voulez-vous migrer la boite mail vers O365 (O/N) ? "  
}
until (($global:migration -eq "O") -or ($global:migration -eq "N"))

if ($global:migration -eq "O")
{
    Connect-AzureAD
    [string]$Consumedlicence = Get-MsolAccountSku | Where-Object AccountSkuId -EQ "O365Domaine:ENTERPRISEPACK" | select ConsumedUnits
    [string]$ActiveLicence = Get-MsolAccountSku | Where-Object AccountSkuId -EQ "O365Domaine:ENTERPRISEPACK" |  select ActiveUnits

    if( ($Consumedlicence.split("=")[1].split("}")[0]) -ge ($ActiveLicence.split("=")[1].split("}")[0] ) )
    {
        clear
        Write-Host "Plus de licence disponible." $Consumedlicence.split("=")[1].split("}")[0] "licences sur" $ActiveLicence.split("=")[1].split("}")[0] "sont affectées"
        do
        {
            $global:migration=Read-Host "Voulez-vous quand même migrer la boite mail vers O365 (O/N) ? "  
        }
        until (($global:migration -eq "O") -or ($global:migration -eq "N"))
    }
    if ($global:migration -eq "O")
       {
            Ask-OnlineArchive
       }
}



}

function Ask-DuplicateAccount
{
do
{
  clear
  $global:copie=Read-Host "Voulez-vous copier un compte existant (O/N) ? "  
}
until (($global:copie -eq "O") -or ($global:copie -eq "N"))

if ($global:copie -eq "O") 
{
   do
    {
        clear
        $global:comptesource=Read-Host "Compte à copier ('prenom.nom'(entité2/entité3) ou 'nom prenom'(entité1)) ?"
    }
    until (Get-QADUser -Identity $global:comptesource)
 }
}

function Ask-Validation
{
do
{
    Clear
    Write-host "************************************************************"
    Write-Host "CREATION DU COMPTE"
    Write-Host "Prenom : $global:prenom"
    Write-Host "Nom : $global:nom"
    Write-Host "username : $global:username"
    Write-Host "displayname : $global:displayname"
    Write-Host "Migration O365 : $global:migration"
    if ($global:archive -eq "O") {Write-Host "Archive en ligne  : $global:archive"}
    Write-Host "Domaine : $global:domaine"
    Write-Host "Password : $global:password"
    Write-Host "NT Account : $global:ntaccount"
    if ($global:copie -eq "O") { Write-Host "Compte à copier : $global:comptesource" }
    Write-Host "************************************************************"
    $global:validation=Read-Host "C'est parti (O/N) ? "  
}
until (($global:validation -eq "O") -or ($global:validation -eq "N"))
If ($global:validation -eq "N") { Show-UserMenu }
}

function Ask-OnlineArchive
{

    do
    {
        $global:archive=Read-Host "Voulez-vous activer l'archive en ligne (O/N) ? "  
    }
    until (($global:archive -eq "O") -or ($global:archive -eq "N"))
}

function RemoveAdUser
{
    Ask-User
    if ($global:domaine -eq "entité1")
    {
        $user = $global:displayname
    }
    else
    {
        $user = $global:username
    }  

    if (!(Get-QADUser -Identity $user)) 
    { 
        Write-Host "le compte n'existe pas - Appuyer sur un touche pour retourner au menu"
        pause
        Show-UserMenu
    }
Remove-ADObject (Get-ADUser $user).distinguishedname -Recursive

#SUPPRESSION DES FICHIERS DE L'UTILISATEUR
###################################################################################################
# J'ai supprimé les différents chemin ici mais en tant normal je défini les variables qui suivent #
###################################################################################################



#if (Test-Path $PERSOHM) {Remove-Item $PERSOHM -Recurse -Force -Verbose }
if (Test-Path $PERSOHM) {[Alphaleonis.Win32.Filesystem.Directory]::Delete($PERSOHM, $true, $true) }
#if (Test-Path $PRFRDSHM) {Remove-Item $PRFRDSHM -Recurse -Force -Verbose}
if (Test-Path $PRFRDSHM) {[Alphaleonis.Win32.Filesystem.Directory]::Delete($PRFRDSHM, $true, $true) }
#if (Test-Path $PROFILEHM) {Remove-Item $PROFILEHM -Recurse -Force -Verbose}
if (Test-Path $PROFILEHM) {[Alphaleonis.Win32.Filesystem.Directory]::Delete($PROFILEHM, $true, $true) }
#if (Test-Path $PROFILETSEHM) {Remove-Item $PROFILETSEHM -Recurse -Force -Verbose}
if (Test-Path $PROFILETSEHM) {[Alphaleonis.Win32.Filesystem.Directory]::Delete($PROFILETSEHM, $true, $true) }
#if (Test-Path $REDIRRDSHM) {Remove-Item $REDIRRDSHM -Recurse -Force -Verbose}
if (Test-Path $REDIRRDSHM) {[Alphaleonis.Win32.Filesystem.Directory]::Delete($REDIRRDSHM, $true, $true) }
#if (Test-Path $OSTHM) {Remove-Item $OSTHM -Recurse -Force -Verbose}
if (Test-Path $OSTHM) {[Alphaleonis.Win32.Filesystem.Directory]::Delete($OSTHM, $true, $true) }

#if (Test-Path $PERSOCH) {Remove-Item $PERSOCH -Recurse -Force -Verbose}
if (Test-Path $PERSOCH) {[Alphaleonis.Win32.Filesystem.Directory]::Delete($PERSOCH, $true, $true) }
#if (Test-Path $BASESCH) {Remove-Item $BASESCH -Recurse -Force -Verbose}
if (Test-Path $BASESCH) {[Alphaleonis.Win32.Filesystem.Directory]::Delete($BASESCH, $true, $true) }
#if (Test-Path $PROFILCH) {Remove-Item $PROFILCH -Recurse -Force -Verbose}
if (Test-Path $PROFILCH) {[Alphaleonis.Win32.Filesystem.Directory]::Delete($PROFILCH, $true, $true) }
#if (Test-Path $OSTCH) {Remove-Item $OSTCH -Recurse -Force -Verbose}
if (Test-Path $OSTCH) {[Alphaleonis.Win32.Filesystem.Directory]::Delete($OSTCH, $true, $true) }

#if (Test-Path $REDIRRDSGIP) {Remove-Item $REDIRRDSGIP -Recurse -Force -Verbose}
if (Test-Path $REDIRRDSGIP) {[Alphaleonis.Win32.Filesystem.Directory]::Delete($REDIRRDSGIP, $true, $true) }
#if (Test-Path $PROFILRDSGIP ) {Remove-Item $PROFILRDSGIP  -Recurse -Force -Verbose}
if (Test-Path $PROFILRDSGIP) {[Alphaleonis.Win32.Filesystem.Directory]::Delete($PROFILRDSGIP, $true, $true) }
#if (Test-Path $OSTGIP ) {Remove-Item $OSTGIP  -Recurse -Force -Verbose}
if (Test-Path $OSTGIP) {[Alphaleonis.Win32.Filesystem.Directory]::Delete($OSTGIP, $true, $true) }

#SUPPRESSION DES PROFILS RESIDUEL SUR LES RDS
$servers = get-QADComputer -SearchRoot 'OuDesServeursRDS'

foreach ($server in $servers)
{
    $PROFIL = "\\" + $server.Name + "\C$\Users\" + $global:username
    if (Test-Path $PROFIL) {Remove-Item $PROFIL -Recurse -Force -Verbose}
    
    $PROFIL = "\\" + $server.Name + "\C$\Users\" + $global:username + ".NETINTRA"
    if (Test-Path $PROFIL) {Remove-Item $PROFIL -Recurse -Force -Verbose}
}  

SynchroDirsync
}

function CreateAdUser
{
    Ask-User
    if (Get-QADUser -Identity $global:username) 
    {
        $global:domaine = "0"
		$global:askuser = 1
        Write-Host "le compte existe déja - Appuyer sur un touche pour retourner au menu"
        pause
        Show-UserMenu
    }
    Ask-MigrationO365
    Ask-DuplicateAccount
    Ask-Validation

    #region <CREATION DU COMPTE AD>
    if ($global:domaine -eq "entité1")
    {
        New-QADUser -Name $global:displayname -ParentContainer $global:OU -FirstName $global:prenom -LastName $global:nom -UserPassword $global:password -SamAccountName $global:displayname -UserPrincipalName ($global:username+"@"+$global:domaine) -DisplayName $global:displayname
    }
    else
    {
        New-QADUser -Name $global:displayname -ParentContainer $global:OU -FirstName $global:prenom -LastName $global:nom -UserPassword $global:password -SamAccountName $global:username -UserPrincipalName ($global:username+"@"+$global:domaine) -DisplayName $global:displayname
    }  
    Start-Sleep -s 30 
    #endregion

    #region <CREATION DU REPERTOIRE PERSONNEL>
    if ($global:domaine -eq "entité1") 
    {
        New-Item -path $global:path -Name $global:displayname  -ItemType directory
        $rep = $global:path + $global:displayname
        #mise en place des droits NTFS sur le dossier
        #try
		#{
			Start-Sleep -s 10
			Disable-Inheritance $rep
		#}
		#Catch
		#{
		#	Continue
		#}
        #$access = Get-Access $rep | Select Account
        #foreach ($account in $access)
        #{
        #    [string]$account = $account
        #    $account = $account.Split("=")[1].split("}")[0]
        #    Remove-Access -Path $rep -Account $account -AccessRights FullControl
        #}
		Start-Sleep -s 10
        Add-Access -Path $rep -Account 'BUILTIN\Administrateurs' -AccessRights FullControl
        Add-Access -Path $rep -Account $global:ntaccount -AccessRights FullControl
        Set-Owner -Path $rep -Account $global:ntaccount
    }

    if ($global:domaine -eq "entité2") 
    {
        New-Item -path $global:path -Name $global:username  -ItemType directory
        $rep = $global:path + $global:username
        Start-Sleep -s 10
        Add-Access -Path $rep -Account $global:ntaccount -AccessRights FullControl
        Set-Owner -Path $rep -Account $global:ntaccount
    }
    #endregion

    #region <COPIE PROFIL>
    if ($global:copie -eq "O")
    {
        Start-Sleep -s 15
        $SOURCE_GRP = @(Get-ADPrincipalGroupMembership -Identity $global:comptesource | select -ExpandProperty distinguishedname)
        if ($SOURCE_GRP.count -gt 0) 
        {
            foreach ($SOURCE_GRP in $SOURCE_GRP) 
            {
                try
				{
					if ($global:domaine -eq "entité2")  {Add-QADGroupMember -identity $SOURCE_GRP -member $global:username}
                	if ($global:domaine -eq "entité1") {Add-QADGroupMember -identity $SOURCE_GRP -member $global:displayname} 
				}
				Catch
				{
					Continue
				}
            }
        }
        $streetaddress = get-QADUser -Identity $global:comptesource  -properties StreetAddress | Select -ExpandProperty StreetAddress
        $PostalCode =get-QADUser -Identity $global:comptesource  -properties PostalCode | Select -ExpandProperty PostalCode
        $POBox = Get-ADUser -Identity $global:comptesource -Properties POBox | select -ExpandProperty POBox
        $City = get-QADUser -Identity $global:comptesource  -properties City | Select -ExpandProperty City
        $Manager = get-QADUser -Identity $global:comptesource  -properties Manager | Select -ExpandProperty Manager
        $Title = get-QADUser -Identity $global:comptesource  -properties Title | Select -ExpandProperty Title
        $Department = get-QADUser -Identity $global:comptesource  -properties Department | Select -ExpandProperty Department
        $Company = get-QADUser -Identity $global:comptesource  -properties Company | Select -ExpandProperty Company
        $Description = get-QADUser -Identity $global:comptesource  -properties Description | Select -ExpandProperty Description
		[string]$site = Get-QADUser -Identity $global:comptesource -Properties extensionAttribute1 | Select -ExpandProperty extensionAttribute1

		if ($global:domaine -eq "entité1") 
    	{
        	Set-ADUser -Identity $global:displayname -Add @{"extensionAttribute1"=$site} -StreetAddress $streetaddress -PostalCode $PostalCode -POBox $POBox -City $City -Manager $Manager -Title $Title -Department $Department -Company $Company -Description $Description
    	}
    	else
    	{
        	Set-ADUser -Identity $global:username -Add @{"extensionAttribute1"=$site} -StreetAddress $streetaddress -PostalCode $PostalCode -POBox $POBox -City $City -Manager $Manager -Title $Title -Department $Department -Company $Company -Description $Description
    	}

        
    }
    #endregion

    #region <CREATION BOITE MAIL>
    Connect-Exchange
    if ($global:domaine -eq "entité1") 
    {
        Enable-exchMailbox $global:displayname -Database $global:DATABASE
    }
    else
    {
        Enable-exchMailbox $global:username -Database $global:DATABASE
    }
    #endregion

    SynchroDirsync 180

    #region <MIGRATION BAL VERS O365 SI DEMANDE>
    if ($global:migration -eq "O")
    {
        Set-OnlineMailbox
    }
    #endregion

    #region <MISE EN PLACE ARCHIVE EN LIGNE>
    if ($global:archive -eq "O")
    {
        Set-OnlineArchive
    }
    #endregion
}

function Set-OnlineArchive
{

if ($global:askuser -eq 1) {Ask-User}

if (!(Get-QADUser -Identity $global:username)) 
    {
        $global:domaine = "0"
        Write-Host "le compte n'existe pas - Appuyer sur un touche pour retourner au menu"
        pause
        Show-Office365Menu
    }
[string]$ArchiveStatus = Get-QADUser -Identity $global:username -Properties msExchArchiveStatus | Select-Object msExchArchiveStatus
$ArchiveStatus = $ArchiveStatus.Split('=')[1]
$ArchiveStatus = $ArchiveStatus.Split('}')[0]

If ($ArchiveStatus -ne "1")
{
	#Archive en ligne pas active
	Set-QADUser -Identity $global:username -ObjectAttributes @{msExchArchiveName='Archive en ligne';msExchRemoteRecipientType='3';msExchArchiveStatus='1'}
	SynchroDirsync
    Get-QADUser -Identity $global:username -Properties DisplayName,title,department,mail,description,msExchArchiveName,msExchRemoteRecipientType,msExchArchiveStatus | Select-Object DisplayName,title,department,mail,description,msExchArchiveName,msExchRemoteRecipientType,msExchArchiveStatus
}
Else
{
	Write-Host 'Archive en ligne de' $ADUser 'déjà active - Appuyer sur un touche pour retourner au menu'
    pause
    Show-Office365Menu
}
Show-Office365Menu
}

function Set-OnlineMailbox
{
    if ($global:askuser -eq 1) {Ask-User}
	
	if (!(Get-QADUser -Identity $global:username)) 
    {
        $global:domaine = "0"
        Write-Host "le compte n'existe pas - Appuyer sur un touche pour retourner au menu"
        pause
        Show-Office365Menu
    }

    Connect-Exchange #Fonction défini dans un module perso 
    Connect-ExchangeOnline #Fonction défini dans un module perso

    [string]$MailboxUid = Get-o365Recipient $global:displayname | select Guid
    $MailboxUid = $MailboxUid.Split("=")[1].split("}")[0]


    $MailboxUid | New-O365MoveRequest -Remote -RemoteHostName 'oph.entité2' -RemoteCredential $CredExch -TargetDeliveryDomain 'O365Domaine.mail.onmicrosoft.com'-BadItemLimit 1000 -AcceptLargeDataLoss
    Write-Host Debut de la migration vers O365
    #Temps que le status de la migration n'est pas complete on attend
    Write-Host En attente de la fin de la migration
    [string]$status = Get-o365MoveRequest -Identity $global:displayname | select Status

    do
    {
        [string]$status = Get-o365MoveRequest -Identity $global:Displayname| select Status
        Write-Host En attente de la fin de la migration
        Start-Sleep -s 5
    }
    until (($status.Split('=')[1].split('}')[0]) -eq 'Completed')
    
    SynchroDirsync 180

    #AFFECTATION D'UNE LICENCE O365
	$bal = $global:username + "@" + $global:domaine
    Set-MsolUser -UserPrincipalName $bal -UsageLocation "FR"
    Set-MsolUserLicense -UserPrincipalName $bal -AddLicenses "O365Domaine:ENTERPRISEPACK"
    [string]$Consumedlicence = Get-MsolAccountSku | Where-Object AccountSkuId -EQ "O365Domaine:ENTERPRISEPACK" | select ConsumedUnits
    [string]$ActiveLicence = Get-MsolAccountSku | Where-Object AccountSkuId -EQ "O365Domaine:ENTERPRISEPACK" |  select ActiveUnits
    Write-Host $Consumedlicence.split("=")[1].split("}")[0] "licences sur" $ActiveLicence.split("=")[1].split("}")[0] "sont affectées"

}

Function Create-SharedMailbox
{
	Ask-User
	Connect-Exchange
	
	New-exchMailbox -UserPrincipalName "$global:username@$global:domaine" -Alias "$global:username" -Database "$global:DATABASE" -Name "$global:username" -OrganizationalUnit "$global:OUBAL" -Password (ConvertTo-SecureString -String 'Messagerie3' -AsPlainText -Force) -DisplayName "$global:username"
	SynchroDirsync 180
	
	Set-OnlineSharedMailbox
	
	Set-o365Mailbox -Identity $global:username –Type shared
	Set-o365Mailbox $global:username -ProhibitSendReceiveQuota 5GB -ProhibitSendQuota 4.75GB -IssueWarningQuota 4.5GB
}

function Set-OnlineSharedMailbox
{
	if ($global:askuser -eq 1) {Ask-User}
	
	if (!(Get-QADUser -Identity $global:username)) 
    {
        $global:domaine = "0"
        Write-Host "le compte n'existe pas - Appuyer sur un touche pour retourner au menu"
        pause
        Show-Office365Menu
    }

    Connect-Exchange
    Connect-ExchangeOnline

    [string]$MailboxUid = Get-o365Recipient $global:username | select Guid
    $MailboxUid = $MailboxUid.Split("=")[1].split("}")[0]


    $MailboxUid | New-O365MoveRequest -Remote -RemoteHostName 'oph.entité2' -RemoteCredential $CredExch -TargetDeliveryDomain 'O365Domaine.mail.onmicrosoft.com'-BadItemLimit 1000 -AcceptLargeDataLoss
    Write-Host Debut de la migration vers O365
    #Temps que le status de la migration n'est pas complete on attend
    Write-Host En attente de la fin de la migration
    [string]$status = Get-o365MoveRequest -Identity $global:username | select Status

    do
    {
        [string]$status = Get-o365MoveRequest -Identity $global:username| select Status
        Write-Host En attente de la fin de la migration
        Start-Sleep -s 5
    }
    until (($status.Split('=')[1].split('}')[0]) -eq 'Completed')
    
    SynchroDirsync 180
}

Function Get-ListRDSServer
{

Get-ADComputer -Filter 'Name -like "*"' | Where-Object {$_.name -match "^SRV-RDS[\d].*|^TS[\d].*|^SRV-RDSCTA-[\d].*|^SRV-RDSHM-[\d].*"} | Export-CSV -Path "C:\Temp\ListeTS.csv" -Delimiter ";" -NoTypeInformation
$global:RDSservers = Get-Content -Path "C:\Temp\ListeTS.csv" | where {$_ -notmatch "name"} | ForEach {$_ -replace """",""}
clear
}

Function FindUserRDS
{

Get-ListRDSServer

$global:username = Read-Host "Nom utilisateur? : "


Foreach ($ServeurTS in $global:RDSservers)
{
    $SplitTS = $ServeurTS.Split(";")
    $TSE = $SplitTS[3]
    try
    {
    	if (Get-TSSession -ComputerName $TSE -UserName *$global:username*)
		{ 
			Write-Host $TSE
			Get-TSSession -ComputerName $TSE -UserName *$global:username* | FT UserName, ClientName, State, IpAddress
		}	
    }
    catch
    {
    Continue
    }
}
Pause
}
#endregion

#region <Main>
Show-PrincipalMenu
#endregion



